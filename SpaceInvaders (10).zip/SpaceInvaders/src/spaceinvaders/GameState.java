
package spaceinvaders;

import java.awt.Graphics;

public interface GameState {
    void update(Board board);
    void render(Graphics g, Board board);
}