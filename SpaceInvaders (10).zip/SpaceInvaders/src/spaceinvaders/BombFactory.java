
package spaceinvaders;

public class BombFactory {

protected static Bomb prototype = new Bomb(0, 0);

    public static void setPrototype(Bomb p) {
        prototype = p;
    }

    public static Bomb createBomb(int x, int y) {
        Bomb clone = prototype.clone();
        clone.setX(x);
        clone.setY(y);
        clone.setDestroyed(false);
        return clone;
    }
}
