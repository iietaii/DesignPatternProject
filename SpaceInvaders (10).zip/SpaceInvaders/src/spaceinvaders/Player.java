package spaceinvaders;

/**
 *
 * @author
 */
public class Player extends Sprite implements Commons {

    private final int START_Y = 400;
    private final int START_X = 270;

    private int width;
    private int dx;

    public Player() {
        setImage(PushPanel.getSharedImage("/img/craft.png")); //edit
        setX(START_X);
        setY(START_Y);
    }

    public void act() {
        x += dx;

        if (x <= 2) {
            x = 2;
        }
        if (x >= BOARD_WIDTH - 2 * width) {
            x = BOARD_WIDTH - 2 * width;
        }
    }

    public int getX() {
        return x;
    }

    public void setDx(int dx) {
        this.dx = dx;
    }

    public void hitByBomb() {
        setDying(true);  
    }

}
