package spaceinvaders;

import java.awt.*;

public class GameOverState implements GameState {

    private static final GameOverState INSTANCE = new GameOverState();

    private GameOverState() {}

    public static GameOverState getInstance() {
        return INSTANCE;
    }

    @Override
    public void update(Board board) {
    }

    @Override
    public void render(Graphics g, Board board) {
        g.setColor(Color.black);
        g.fillRect(0, 0, Commons.BOARD_WIDTH, Commons.BOARD_HEIGTH);

        Image bg = PushPanel.getSharedImage("/img/gameover.png");
        g.drawImage(bg, 0, 0, Commons.BOARD_WIDTH, Commons.BOARD_HEIGTH, board);

        g.setColor(new Color(0, 0, 0, 160));
        g.fillRect(50, Commons.BOARD_WIDTH / 2 - 70, Commons.BOARD_WIDTH - 100, 120);
        g.setColor(Color.white);
        g.drawRect(50, Commons.BOARD_WIDTH / 2 - 70, Commons.BOARD_WIDTH - 100, 120);

        Font big = new Font("Helvetica", Font.BOLD, 24);
        g.setFont(big);
        FontMetrics fm = board.getFontMetrics(big);
        String gameOverMessage = "Seu planeta nos pertence agora...";
        g.drawString(gameOverMessage,
                (Commons.BOARD_WIDTH - fm.stringWidth(gameOverMessage)) / 2,
                Commons.BOARD_WIDTH / 2);

        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString("Press SPACE to play again", 170, Commons.BOARD_WIDTH / 2 + 50);
    }
}