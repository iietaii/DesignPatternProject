package spaceinvaders;

import java.awt.*;
import java.util.Random;

public class PlayingState implements GameState {

    private static final PlayingState INSTANCE = new PlayingState();

    private PlayingState() {}

    public static PlayingState getInstance() {
        return INSTANCE;
    }

    @Override
    public void update(Board board) {
        if (board.deaths == Commons.NUMBER_OF_ALIENS_TO_DESTROY) {
            board.finishGame(true);
            return;
        }

        board.getPlayer().act();

        Shot shot = board.getShot();
        if (shot.isVisible()) {
            int shotX = shot.getX(), shotY = shot.getY();
            for (Alien alien : board.aliens) {
                if (alien.isVisible() && shot.isVisible()
                        && shotX >= alien.getX() && shotX <= alien.getX() + Commons.ALIEN_WIDTH
                        && shotY >= alien.getY() && shotY <= alien.getY() + Commons.ALIEN_HEIGHT) {

                    alien.setImage(PushPanel.getSharedImage("/img/explosion.png"));
                    alien.die();
                    board.deaths++;
                    shot.die();
                }
            }
            int y = shot.getY() - 8;
            if (y < 0) {
                shot.die();
            } else {
                shot.setY(y);
            }
        }

        for (Alien a : board.aliens) {
            int x = a.getX();
            if (x >= Commons.BOARD_WIDTH - Commons.BORDER_RIGHT && board.direction != -1) {
                board.direction = -1;
                board.aliens.forEach(al -> al.setY(al.getY() + Commons.GO_DOWN));
            }
            if (x <= Commons.BORDER_LEFT && board.direction != 1) {
                board.direction = 1;
                board.aliens.forEach(al -> al.setY(al.getY() + Commons.GO_DOWN));
            }
        }

        board.aliens.forEach(alien -> {
            if (alien.isVisible()) {
                if (alien.getY() > Commons.GROUND - Commons.ALIEN_HEIGHT) {
                    board.finishGame(false);
                }
                alien.act(board.direction);
            }
        });

        Random r = new Random();
        for (Alien a : board.aliens) {
            int chance = r.nextInt(15);
            Bomb b = a.getBomb();
            if (chance == Commons.CHANCE && a.isVisible() && b.isDestroyed()) {
                b.setDestroyed(false);
                b.setX(a.getX());
                b.setY(a.getY());
            }
            if (!b.isDestroyed()) {
                b.setY(b.getY() + 1);
                if (b.getY() >= Commons.GROUND - Commons.BOMB_HEIGHT) {
                    b.setDestroyed(true);
                }

                Player player = board.getPlayer();
                if (player.isVisible()
                        && b.getX() >= player.getX() && b.getX() <= player.getX() + Commons.PLAYER_WIDTH
                        && b.getY() >= player.getY() && b.getY() <= player.getY() + Commons.PLAYER_HEIGHT) {

                    player.setImage(PushPanel.getSharedImage("/img/explosion.png"));
                    player.hitByBomb();
                    b.setDestroyed(true);
                }
            }
        }
    }

    @Override
    public void render(Graphics g, Board board) {
        g.setColor(Color.black);
        g.fillRect(0, 0, Commons.BOARD_WIDTH, Commons.BOARD_HEIGTH);
        g.setColor(Color.green);
        g.drawLine(0, Commons.GROUND, Commons.BOARD_WIDTH, Commons.GROUND);

        drawAliens(g, board);
        drawPlayer(g, board);
        drawShot(g, board);
        drawBombing(g, board);

        g.setColor(Color.white);
        g.setFont(new Font("Arial", Font.BOLD, 14));
        g.drawString("Score: " + ScoreManager.getInstance().getScore(), 10, 20);
    }

    private void drawAliens(Graphics g, Board board) {
        for (Alien alien : board.aliens) {
            if (alien.isVisible()) {
                g.drawImage(alien.getImage(), alien.getX(), alien.getY(), board);
            }
            if (alien.isDying()) {
                alien.die();
            }
        }
    }

    private void drawPlayer(Graphics g, Board board) {
        Player player = board.getPlayer();
        if (player.isVisible()) {
            g.drawImage(player.getImage(), player.getX(), player.getY(), board);
        }
        if (player.isDying()) {
            player.die();
            board.finishGame(false);
        }
    }

    private void drawShot(Graphics g, Board board) {
        Shot shot = board.getShot();
        if (shot.isVisible()) {
            g.drawImage(shot.getImage(), shot.getX(), shot.getY(), board);
        }
    }

    private void drawBombing(Graphics g, Board board) {
        for (Alien a : board.aliens) {
            Bomb b = a.getBomb();
            if (!b.isDestroyed()) {
                g.drawImage(b.getImage(), b.getX(), b.getY(), board);
            }
        }
    }
}