
package spaceinvaders;

public class ShootCommand implements Command {
    private Board board; 

    public ShootCommand(Board board) {
        this.board = board;
    }

    @Override
    public void execute() {
        if (!board.getShot().isVisible()) {
            board.setShot(new Shot(board.getPlayer().getX(), board.getPlayer().getY()));
        }
    }

}