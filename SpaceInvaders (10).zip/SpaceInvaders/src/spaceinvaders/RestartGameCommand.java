package spaceinvaders;

public class RestartGameCommand implements Command {

    private final Board board;

    public RestartGameCommand(Board board) {
        this.board = board;
    }

    @Override
    public void execute() {
        
        ScoreManager.getInstance().reset();
        board.deaths = 0;           
        board.direction = -1;       
        board.currentState = PlayingState.getInstance();

        board.gameInit();
    }
}