 package spaceinvaders;

public class MoveLeftCommand implements Command {

    private Player player;

    public MoveLeftCommand(Player player) {
        this.player = player;
    }

    public void execute() {
        player.setDx(-2);
    }
}
