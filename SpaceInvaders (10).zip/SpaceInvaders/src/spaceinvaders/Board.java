package spaceinvaders;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class Board extends JPanel implements Runnable, Commons {

    private static final long serialVersionUID = 1L;
    private Dimension d;
    protected ArrayList<Alien> aliens;
    private Player player;
    private Shot shot;

    private int alienX = 150;
    private int alienY = 25;

    protected int deaths = 0;
    protected int direction = -1;
    protected String message = "Game Over";

    private final String expl = "/img/explosion.png";
    private Thread animator;
    protected GameState currentState;

    public Board() {
        addKeyListener(new TAdapter());
        setFocusable(true);
        setBackground(Color.black);
        setDoubleBuffered(true);
        d = new Dimension(BOARD_WIDTH, BOARD_HEIGTH);

        currentState = PlayingState.getInstance();
        gameInit();

        animator = new Thread(this);
        animator.start();
    }

    public String getMessage() {
        return message;
    }

    public void gameInit() {
        aliens = new ArrayList<>();
        Alien prototypeAlien = PushPanel.createAlien(alienX, alienY);
        AlienFactory alienFactory = new AlienFactory(prototypeAlien);

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                Alien alien = alienFactory.createAlien(alienX + 18 * j, alienY + 18 * i);
                aliens.add(alien);
            }
        }

        player = PushPanel.createPlayer();
        shot = new Shot();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        currentState.render(g, this); 
        Toolkit.getDefaultToolkit().sync();
    }

    public void animationCycle() {
        currentState.update(this); 
    }

    public void finishGame(boolean won) {
        if (won) {
            message = "Parabéns! Você salvou a galáxia!";
            currentState = VictoryState.getInstance();
        } else {
            message = "Seu planeta nos pertence agora...";
            currentState = GameOverState.getInstance();
        }
    }

    @Override
    public void run() {
        long beforeTime = System.currentTimeMillis();
        while (true) {
            repaint();
            animationCycle();

            long diff = System.currentTimeMillis() - beforeTime;
            long sleep = DELAY - diff;
            if (sleep < 0) {
                sleep = 1;
            }
            try {
                Thread.sleep(sleep);
            } catch (InterruptedException e) {
                return;
            }
            beforeTime = System.currentTimeMillis();
        }
    }

    public Player getPlayer() {
        return player;
    }

    public Shot getShot() {
        return shot;
    }

    public void setShot(Shot s) {
        this.shot = s;
    }

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {
            int key = e.getKeyCode();

            if (currentState instanceof PlayingState) {
                Command cmd = null;
                if (key == KeyEvent.VK_LEFT) {
                    cmd = new MoveLeftCommand(player);
                }
                if (key == KeyEvent.VK_RIGHT) {
                    cmd = new MoveRightCommand(player);
                }
                if (key == KeyEvent.VK_SPACE) {
                    cmd = new ShootCommand(Board.this);
                }
                if (cmd != null) {
                    cmd.execute();
                }
            } else if (key == KeyEvent.VK_SPACE
                    && (currentState instanceof GameOverState || currentState instanceof VictoryState)) {
                new RestartGameCommand(Board.this).execute();
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            player.setDx(0);
        }
    }
}