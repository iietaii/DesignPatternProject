package spaceinvaders;

import javax.swing.ImageIcon;

public class Alien extends Sprite implements Cloneable {

    private Bomb bomb;

   

  public void die() {
    setVisible(false);
    ScoreManager.getInstance().addPoints(100);
}

    public Alien(int x, int y) {
        this.x = x;
        this.y = y;
        bomb = PushPanel.createBomb(x, y);//edit
        setImage(PushPanel.getSharedImage("/img/alien.png"));//edit
    }

    public void act(int direction) {
        this.x += direction;
    }

    public Bomb getBomb() {
        return bomb;
    }

    @Override
    public Alien clone() {
        try {
            Alien cloned = (Alien) super.clone();
            cloned.bomb = this.bomb.clone();
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}
