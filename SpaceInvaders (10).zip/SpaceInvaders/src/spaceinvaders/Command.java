
package spaceinvaders;

public interface Command {
    void execute();
}



