package spaceinvaders;

import javax.swing.ImageIcon;

public class Shot extends Sprite {

    private final int H_SPACE = 6;
    private final int V_SPACE = 1;

    public Shot() {
    }

    public Shot(int x, int y) {

        setImage(PushPanel.getSharedImage("/img/shot.png"));
        setX(x + H_SPACE);
        setY(y - V_SPACE);
    }
}
