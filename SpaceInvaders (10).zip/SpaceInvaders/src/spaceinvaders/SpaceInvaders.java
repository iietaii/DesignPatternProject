package spaceinvaders;

public class SpaceInvaders {

    public static void main(String[] args) {
  
        PushPanel.showIntroScreen();

        PushPanel.startButton.addActionListener(e -> {
            PushPanel.introFrame.dispose(); 
            PushPanel.startGame(); 
        });

        PushPanel.helpButton.addActionListener(e -> {
            PushPanel.showHelpScreen(); 
        });
    }
}


